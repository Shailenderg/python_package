class Good:
    def __init__(self):
        print("constuctor is working")
    def goodfunc(self,number):
        print("this is a testing of function")
        return number