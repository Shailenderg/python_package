import numbers


def achafunc(number):
    print("this is a function")
    return number