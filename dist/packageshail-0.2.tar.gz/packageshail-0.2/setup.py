from setuptools import setup
setup(name="packageshail",
version="0.2",
description="this is code with shailender",
packages=['packageshail'],
install_requires=[])