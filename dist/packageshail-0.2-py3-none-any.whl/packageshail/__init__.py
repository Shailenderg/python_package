import numbers

class Acha:
    def __init__(self):
        print("constuctor ban gya")
    def achafunc(self,number):
        print("this is a function")
        return number